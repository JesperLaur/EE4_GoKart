/*******************************************************************************
* File Name: Gear_REV.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Gear_REV_H) /* Pins Gear_REV_H */
#define CY_PINS_Gear_REV_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Gear_REV_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Gear_REV__PORT == 15 && ((Gear_REV__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Gear_REV_Write(uint8 value);
void    Gear_REV_SetDriveMode(uint8 mode);
uint8   Gear_REV_ReadDataReg(void);
uint8   Gear_REV_Read(void);
void    Gear_REV_SetInterruptMode(uint16 position, uint16 mode);
uint8   Gear_REV_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Gear_REV_SetDriveMode() function.
     *  @{
     */
        #define Gear_REV_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Gear_REV_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Gear_REV_DM_RES_UP          PIN_DM_RES_UP
        #define Gear_REV_DM_RES_DWN         PIN_DM_RES_DWN
        #define Gear_REV_DM_OD_LO           PIN_DM_OD_LO
        #define Gear_REV_DM_OD_HI           PIN_DM_OD_HI
        #define Gear_REV_DM_STRONG          PIN_DM_STRONG
        #define Gear_REV_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Gear_REV_MASK               Gear_REV__MASK
#define Gear_REV_SHIFT              Gear_REV__SHIFT
#define Gear_REV_WIDTH              1u

/* Interrupt constants */
#if defined(Gear_REV__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Gear_REV_SetInterruptMode() function.
     *  @{
     */
        #define Gear_REV_INTR_NONE      (uint16)(0x0000u)
        #define Gear_REV_INTR_RISING    (uint16)(0x0001u)
        #define Gear_REV_INTR_FALLING   (uint16)(0x0002u)
        #define Gear_REV_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Gear_REV_INTR_MASK      (0x01u) 
#endif /* (Gear_REV__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Gear_REV_PS                     (* (reg8 *) Gear_REV__PS)
/* Data Register */
#define Gear_REV_DR                     (* (reg8 *) Gear_REV__DR)
/* Port Number */
#define Gear_REV_PRT_NUM                (* (reg8 *) Gear_REV__PRT) 
/* Connect to Analog Globals */                                                  
#define Gear_REV_AG                     (* (reg8 *) Gear_REV__AG)                       
/* Analog MUX bux enable */
#define Gear_REV_AMUX                   (* (reg8 *) Gear_REV__AMUX) 
/* Bidirectional Enable */                                                        
#define Gear_REV_BIE                    (* (reg8 *) Gear_REV__BIE)
/* Bit-mask for Aliased Register Access */
#define Gear_REV_BIT_MASK               (* (reg8 *) Gear_REV__BIT_MASK)
/* Bypass Enable */
#define Gear_REV_BYP                    (* (reg8 *) Gear_REV__BYP)
/* Port wide control signals */                                                   
#define Gear_REV_CTL                    (* (reg8 *) Gear_REV__CTL)
/* Drive Modes */
#define Gear_REV_DM0                    (* (reg8 *) Gear_REV__DM0) 
#define Gear_REV_DM1                    (* (reg8 *) Gear_REV__DM1)
#define Gear_REV_DM2                    (* (reg8 *) Gear_REV__DM2) 
/* Input Buffer Disable Override */
#define Gear_REV_INP_DIS                (* (reg8 *) Gear_REV__INP_DIS)
/* LCD Common or Segment Drive */
#define Gear_REV_LCD_COM_SEG            (* (reg8 *) Gear_REV__LCD_COM_SEG)
/* Enable Segment LCD */
#define Gear_REV_LCD_EN                 (* (reg8 *) Gear_REV__LCD_EN)
/* Slew Rate Control */
#define Gear_REV_SLW                    (* (reg8 *) Gear_REV__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Gear_REV_PRTDSI__CAPS_SEL       (* (reg8 *) Gear_REV__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Gear_REV_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Gear_REV__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Gear_REV_PRTDSI__OE_SEL0        (* (reg8 *) Gear_REV__PRTDSI__OE_SEL0) 
#define Gear_REV_PRTDSI__OE_SEL1        (* (reg8 *) Gear_REV__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Gear_REV_PRTDSI__OUT_SEL0       (* (reg8 *) Gear_REV__PRTDSI__OUT_SEL0) 
#define Gear_REV_PRTDSI__OUT_SEL1       (* (reg8 *) Gear_REV__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Gear_REV_PRTDSI__SYNC_OUT       (* (reg8 *) Gear_REV__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Gear_REV__SIO_CFG)
    #define Gear_REV_SIO_HYST_EN        (* (reg8 *) Gear_REV__SIO_HYST_EN)
    #define Gear_REV_SIO_REG_HIFREQ     (* (reg8 *) Gear_REV__SIO_REG_HIFREQ)
    #define Gear_REV_SIO_CFG            (* (reg8 *) Gear_REV__SIO_CFG)
    #define Gear_REV_SIO_DIFF           (* (reg8 *) Gear_REV__SIO_DIFF)
#endif /* (Gear_REV__SIO_CFG) */

/* Interrupt Registers */
#if defined(Gear_REV__INTSTAT)
    #define Gear_REV_INTSTAT            (* (reg8 *) Gear_REV__INTSTAT)
    #define Gear_REV_SNAP               (* (reg8 *) Gear_REV__SNAP)
    
	#define Gear_REV_0_INTTYPE_REG 		(* (reg8 *) Gear_REV__0__INTTYPE)
#endif /* (Gear_REV__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Gear_REV_H */


/* [] END OF FILE */
