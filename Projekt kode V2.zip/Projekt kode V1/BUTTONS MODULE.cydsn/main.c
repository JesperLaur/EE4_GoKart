 /* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "project.h"
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>


// Sampling time in seconds

//Ints

//floats
static float Speed = 7.5;
static float Setpoint;


//Bools
int CCState;
int Brake; 

void Buttons()
{
    if (CyPins_ReadPin(Button_1_0) < 8 && Speed > 5)                            //button 1
    {
       Setpoint = Speed; 
       CCState = 0;
        if (Setpoint > 20)
            {
                Setpoint = 20;
            }
        if (Setpoint < 5)
            {
                Setpoint = 5;    
            }

    }
    
    else if (CyPins_ReadPin(Button_2_0) < 8)                                             //button 2
    {
       Setpoint = Speed + 5; 
        if (Setpoint > 20)
        {
            Setpoint = 20;
        }
       
    }
   
     else if (CyPins_ReadPin(Button_3_0) < 4 && CCState == 0)                            //button 3 first press
    {
        CCState = 1;
    }
    
     else if (CyPins_ReadPin(Button_3_0) < 4 && CCState == 1)                            //button 3 second press
    {
        CCState = 0;    
    }
    
    else if (CyPins_ReadPin(Button_4_0) < 4)                                             //button 4
    {
       Setpoint = Speed - 5; 
       if (Setpoint < 5)
        {
            Setpoint = 5;   
        }
    }  
}

void uart ()
{
    char buffer[256];
        
 snprintf(buffer, sizeof(buffer), "%i; %i, %f, %f \r\n", 
		CCState, Brake, Setpoint, Speed); 
UART_PutString(buffer);
CyDelay(1000);
}
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    UART_Start();
    for(;;)
    {
    
    uart();
 
    Buttons();
    
    }
}

/* [] END OF FILE */
