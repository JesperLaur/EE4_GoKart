/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#define Pi 3.1415926535897          //Pi
#define WheelRadius 0.13949         //Wheel radius in meters


float Speed;                 //Speed measurement
float RotationalSpeed;       //Frequency measurement
float pedaloutput;
bool CCState = 0; 
int Gear = 1;   




void uart ()
{
    char buffer[256];
        
 snprintf(buffer, sizeof(buffer), "%f  \r\n", Speed); 
UART_PutString(buffer);
CyDelay(250);
}

CY_ISR(SpeedMeasurement)                                                //Speed measurement block
{
    RotationalSpeed = (4*(Counter_ReadCapture()));                      //Frequency calculation
    Speed = (2*Pi*WheelRadius*(RotationalSpeed/20)*3.6);                //Final speed in km/h
    Counter_ReadStatusRegister();                                       //clears counter register
    uart();
}
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    
    //Speed Measurment Components
    Timer_Start();                          //Start the timer component
    Counter_Start();                        //Start the counter component
    isr_speed_StartEx(SpeedMeasurement);    //Start the ISR Component for SpeedMeasurement
    UART_Start();
    
    for(;;)
    {
    
    }
}
