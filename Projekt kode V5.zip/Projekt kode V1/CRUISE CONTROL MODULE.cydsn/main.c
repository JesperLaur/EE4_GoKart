/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>


#define Kp 0.0371                   // Proportional gain
#define Ki 0.7143                   // Integral gain
#define Ts 0.25                    // Sampling time in seconds

//Ints
int Gear;

//floats
float Speed=10;                 //Speed measurement
float RotationalSpeed;       //Frequency measurement
float Setpoint= 15;              //User setpoint
float SpeedSignal;           //Speed signal out to SpeedIn


//Regulation definitions
float error;                  //Error between current speed and setpoint
float integral=0;               //Integral of the error
float control;                      //Calculated control signal
float ErrorOld;
float IntOld;

bool CCState = 1;   


void CruiseControl()//Bør måske ligge i et interrupt                    //Cruise control code
{
    if (CCState == 1)          //Limiters for if code
    {
        error = Setpoint - Speed;                                       //Calculates error
        integral = IntOld + (Ts/2) * (error + ErrorOld);                //Calculates integral part | += adds the calculated part to the current value of integral.
        control = Kp * (error + Ki * integral)+0.9;                     //Calculates the control signal value 
        SpeedSignal = control*62.5;                                     //Calcuation of the speed signal to the VDAC8. 
        
        ErrorOld = error;                                               //Saving old values
        IntOld = integral;                                              //Saving old values
        UART_PutString("Entered if string, active\r\n");
       if (SpeedSignal > 255)                                           //if SpeedSignal higher than 3.9
        {
            VDAC8_SetValue(255);                                           //Sets the value of the VDAC output to max. 
          UART_PutString("speedsignal is over 255\r\n");
        }
    
        else                                                                //if SpeedSignal Lower than 3.9
        {
            VDAC8_SetValue(SpeedSignal);                                    //Sets the value of the VDAC output to the value of the variable. 
        UART_PutString("speedsignal is under 255\r\n");
        }  
    }
    //End of if
   
    else 
    {
     VDAC8_SetValue(0);                                                 //Sets speed signal to 0  
    UART_PutString("Entered else string, inactive\r\n");
    }
    CyDelay(250);
    
}
void uart ()
{
    char buffer[256];
        
 snprintf(buffer, sizeof(buffer), " Speedsignal: %i  \r\n\r\n", 
		SpeedSignal); 
UART_PutString(buffer);

}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    VDAC8_Start();                          //Start the VDAC8 component 
    Opamp_Start();  
    UART_Start();
    for(;;)
    {
        CruiseControl();
        uart();
    }
}

/* [] END OF FILE */
