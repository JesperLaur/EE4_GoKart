/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 * testet, virker
 * ========================================
*/
#include "project.h"
static float Speed = 5;
static float setpoint = 1;

#define CCState 0

CY_ISR(LCD_Control)
{
            CharLCD_WriteControl(CharLCD_CLEAR_DISPLAY);                        //Clear display to erase old data 
            
            // Speed Measurement
            CharLCD_PosPrintString(0u,0u, "Hastighed:");                        //Prints the charachters to the screen in the given place
            CharLCD_PosPrintString(0u,16u, "Km/t");                             //Prints the charachters to the screen in the given place
            CharLCD_Position(0u,11u);                                           //Sets cursor position to the given position
            CharLCD_PrintNumber(Speed);                                         //Prints the value of the variable to the screen
          
            // Setpoint
            CharLCD_PosPrintString(2u,0u, "Setpunkt:");                         //Prints the charachters to the screen in the given place
            CharLCD_PosPrintString(2u,16u, "Km/t");                             //Prints the charachters to the screen in the given place
            CharLCD_Position(2u,11u);                                           //Sets cursor position to the given position
            CharLCD_PrintNumber(setpoint);                                      //Prints the value of the variable to the screen

            // Cruisecontrol Status
            if (CCState == 1)
            {
             CharLCD_PosPrintString(1u,0u, "Fartpilot: Pauset"); 
            }
            else
            {
                CharLCD_PosPrintString(1u,0u, "Fartpilot: Aktiv"); 
            }
}

void InputValues() 
{
    Speed = Speed + 1; 
    setpoint = setpoint + 2;
    CyDelay(250);
    
}
int main(void)
  
{
    
    CyGlobalIntEnable; 

    
    I2C_CharLCD_Start();                    //Start the LCD component
	CharLCD_Start();                        //Start the LCD component
    Timer_LCD_Start();                      //Start the LCD timer
    isr_LCD_StartEx(LCD_Control);           //Start the ISR Component
    for(;;)
    {
       InputValues();
    }
}

/* [] END OF FILE */
