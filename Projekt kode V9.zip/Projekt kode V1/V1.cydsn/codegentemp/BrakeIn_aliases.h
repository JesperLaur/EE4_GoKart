/*******************************************************************************
* File Name: BrakeIn.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BrakeIn_ALIASES_H) /* Pins BrakeIn_ALIASES_H */
#define CY_PINS_BrakeIn_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define BrakeIn_0			(BrakeIn__0__PC)
#define BrakeIn_0_INTR	((uint16)((uint16)0x0001u << BrakeIn__0__SHIFT))

#define BrakeIn_INTR_ALL	 ((uint16)(BrakeIn_0_INTR))

#endif /* End Pins BrakeIn_ALIASES_H */


/* [] END OF FILE */
