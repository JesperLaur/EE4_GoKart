/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

int CCState;
int Gear;

void GearMonitor ()
{
    if (CyPins_ReadPin(Gear_FWD_0) < 4)                                           //Forwards enabled
    {
        Gear = 1; 
        CCState =0; 
    }
    
    else if (CyPins_ReadPin(Gear_REV_0) < 4)                                           //Reverse enabled
    {
        Gear = 2;   
        CCState = 1;
    }
   
    else                                                                          //Park enabled 
    {
        Gear = 0;
        CCState = 1;
    }
}
void uart()
{
    int pinsread = CyPins_ReadPin(Gear_FWD_0);
    	char buffer[256];
        
// snprintf(buffer, sizeof(buffer), "%i; %i \r\n", CCState, Gear); 
//UART_1_PutString(buffer);
//CyDelay(10);
sniprintf(buffer, sizeof(buffer), "%.i, %i, %i \r\n", CCState,Gear, pinsread);
                UART_1_PutString(buffer);
                
                CyDelay(1000);
}
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    UART_1_Start();
    for(;;)
    {
       GearMonitor ();
        uart();
    }
}

/* [] END OF FILE */
