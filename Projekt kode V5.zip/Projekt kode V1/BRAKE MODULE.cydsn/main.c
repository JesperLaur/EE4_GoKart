/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 * Testet, Virker
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

int CCState;
int Brake; 

void BrakeMonitor ()
{
    if (CyPins_ReadPin(BrakeIn_0) < 1)                                            //Brake engaged
    {
        Brake = 1;
        CCState = 1;
    }
    else                                                                          //Brake disengaged
    {
        Brake = 0;
        CCState = 0;
    }
}
void uart ()
{
    char buffer[256];
        
 snprintf(buffer, sizeof(buffer), "%i; %i \r\n", 
		CCState, Brake); 
UART_PutString(buffer);
CyDelay(1000);
}
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    UART_Start();
    for(;;)
    {
        uart();
        BrakeMonitor();
    }
}

/* [] END OF FILE */
