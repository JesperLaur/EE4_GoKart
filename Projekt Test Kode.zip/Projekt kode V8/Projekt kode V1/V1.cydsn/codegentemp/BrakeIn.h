/*******************************************************************************
* File Name: BrakeIn.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BrakeIn_H) /* Pins BrakeIn_H */
#define CY_PINS_BrakeIn_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "BrakeIn_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 BrakeIn__PORT == 15 && ((BrakeIn__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    BrakeIn_Write(uint8 value);
void    BrakeIn_SetDriveMode(uint8 mode);
uint8   BrakeIn_ReadDataReg(void);
uint8   BrakeIn_Read(void);
void    BrakeIn_SetInterruptMode(uint16 position, uint16 mode);
uint8   BrakeIn_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the BrakeIn_SetDriveMode() function.
     *  @{
     */
        #define BrakeIn_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define BrakeIn_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define BrakeIn_DM_RES_UP          PIN_DM_RES_UP
        #define BrakeIn_DM_RES_DWN         PIN_DM_RES_DWN
        #define BrakeIn_DM_OD_LO           PIN_DM_OD_LO
        #define BrakeIn_DM_OD_HI           PIN_DM_OD_HI
        #define BrakeIn_DM_STRONG          PIN_DM_STRONG
        #define BrakeIn_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define BrakeIn_MASK               BrakeIn__MASK
#define BrakeIn_SHIFT              BrakeIn__SHIFT
#define BrakeIn_WIDTH              1u

/* Interrupt constants */
#if defined(BrakeIn__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in BrakeIn_SetInterruptMode() function.
     *  @{
     */
        #define BrakeIn_INTR_NONE      (uint16)(0x0000u)
        #define BrakeIn_INTR_RISING    (uint16)(0x0001u)
        #define BrakeIn_INTR_FALLING   (uint16)(0x0002u)
        #define BrakeIn_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define BrakeIn_INTR_MASK      (0x01u) 
#endif /* (BrakeIn__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define BrakeIn_PS                     (* (reg8 *) BrakeIn__PS)
/* Data Register */
#define BrakeIn_DR                     (* (reg8 *) BrakeIn__DR)
/* Port Number */
#define BrakeIn_PRT_NUM                (* (reg8 *) BrakeIn__PRT) 
/* Connect to Analog Globals */                                                  
#define BrakeIn_AG                     (* (reg8 *) BrakeIn__AG)                       
/* Analog MUX bux enable */
#define BrakeIn_AMUX                   (* (reg8 *) BrakeIn__AMUX) 
/* Bidirectional Enable */                                                        
#define BrakeIn_BIE                    (* (reg8 *) BrakeIn__BIE)
/* Bit-mask for Aliased Register Access */
#define BrakeIn_BIT_MASK               (* (reg8 *) BrakeIn__BIT_MASK)
/* Bypass Enable */
#define BrakeIn_BYP                    (* (reg8 *) BrakeIn__BYP)
/* Port wide control signals */                                                   
#define BrakeIn_CTL                    (* (reg8 *) BrakeIn__CTL)
/* Drive Modes */
#define BrakeIn_DM0                    (* (reg8 *) BrakeIn__DM0) 
#define BrakeIn_DM1                    (* (reg8 *) BrakeIn__DM1)
#define BrakeIn_DM2                    (* (reg8 *) BrakeIn__DM2) 
/* Input Buffer Disable Override */
#define BrakeIn_INP_DIS                (* (reg8 *) BrakeIn__INP_DIS)
/* LCD Common or Segment Drive */
#define BrakeIn_LCD_COM_SEG            (* (reg8 *) BrakeIn__LCD_COM_SEG)
/* Enable Segment LCD */
#define BrakeIn_LCD_EN                 (* (reg8 *) BrakeIn__LCD_EN)
/* Slew Rate Control */
#define BrakeIn_SLW                    (* (reg8 *) BrakeIn__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define BrakeIn_PRTDSI__CAPS_SEL       (* (reg8 *) BrakeIn__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define BrakeIn_PRTDSI__DBL_SYNC_IN    (* (reg8 *) BrakeIn__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define BrakeIn_PRTDSI__OE_SEL0        (* (reg8 *) BrakeIn__PRTDSI__OE_SEL0) 
#define BrakeIn_PRTDSI__OE_SEL1        (* (reg8 *) BrakeIn__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define BrakeIn_PRTDSI__OUT_SEL0       (* (reg8 *) BrakeIn__PRTDSI__OUT_SEL0) 
#define BrakeIn_PRTDSI__OUT_SEL1       (* (reg8 *) BrakeIn__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define BrakeIn_PRTDSI__SYNC_OUT       (* (reg8 *) BrakeIn__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(BrakeIn__SIO_CFG)
    #define BrakeIn_SIO_HYST_EN        (* (reg8 *) BrakeIn__SIO_HYST_EN)
    #define BrakeIn_SIO_REG_HIFREQ     (* (reg8 *) BrakeIn__SIO_REG_HIFREQ)
    #define BrakeIn_SIO_CFG            (* (reg8 *) BrakeIn__SIO_CFG)
    #define BrakeIn_SIO_DIFF           (* (reg8 *) BrakeIn__SIO_DIFF)
#endif /* (BrakeIn__SIO_CFG) */

/* Interrupt Registers */
#if defined(BrakeIn__INTSTAT)
    #define BrakeIn_INTSTAT            (* (reg8 *) BrakeIn__INTSTAT)
    #define BrakeIn_SNAP               (* (reg8 *) BrakeIn__SNAP)
    
	#define BrakeIn_0_INTTYPE_REG 		(* (reg8 *) BrakeIn__0__INTTYPE)
#endif /* (BrakeIn__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_BrakeIn_H */


/* [] END OF FILE */
