/*******************************************************************************
* File Name: VSpeedOut.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_VSpeedOut_H) /* Pins VSpeedOut_H */
#define CY_PINS_VSpeedOut_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "VSpeedOut_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 VSpeedOut__PORT == 15 && ((VSpeedOut__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    VSpeedOut_Write(uint8 value);
void    VSpeedOut_SetDriveMode(uint8 mode);
uint8   VSpeedOut_ReadDataReg(void);
uint8   VSpeedOut_Read(void);
void    VSpeedOut_SetInterruptMode(uint16 position, uint16 mode);
uint8   VSpeedOut_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the VSpeedOut_SetDriveMode() function.
     *  @{
     */
        #define VSpeedOut_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define VSpeedOut_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define VSpeedOut_DM_RES_UP          PIN_DM_RES_UP
        #define VSpeedOut_DM_RES_DWN         PIN_DM_RES_DWN
        #define VSpeedOut_DM_OD_LO           PIN_DM_OD_LO
        #define VSpeedOut_DM_OD_HI           PIN_DM_OD_HI
        #define VSpeedOut_DM_STRONG          PIN_DM_STRONG
        #define VSpeedOut_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define VSpeedOut_MASK               VSpeedOut__MASK
#define VSpeedOut_SHIFT              VSpeedOut__SHIFT
#define VSpeedOut_WIDTH              1u

/* Interrupt constants */
#if defined(VSpeedOut__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in VSpeedOut_SetInterruptMode() function.
     *  @{
     */
        #define VSpeedOut_INTR_NONE      (uint16)(0x0000u)
        #define VSpeedOut_INTR_RISING    (uint16)(0x0001u)
        #define VSpeedOut_INTR_FALLING   (uint16)(0x0002u)
        #define VSpeedOut_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define VSpeedOut_INTR_MASK      (0x01u) 
#endif /* (VSpeedOut__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define VSpeedOut_PS                     (* (reg8 *) VSpeedOut__PS)
/* Data Register */
#define VSpeedOut_DR                     (* (reg8 *) VSpeedOut__DR)
/* Port Number */
#define VSpeedOut_PRT_NUM                (* (reg8 *) VSpeedOut__PRT) 
/* Connect to Analog Globals */                                                  
#define VSpeedOut_AG                     (* (reg8 *) VSpeedOut__AG)                       
/* Analog MUX bux enable */
#define VSpeedOut_AMUX                   (* (reg8 *) VSpeedOut__AMUX) 
/* Bidirectional Enable */                                                        
#define VSpeedOut_BIE                    (* (reg8 *) VSpeedOut__BIE)
/* Bit-mask for Aliased Register Access */
#define VSpeedOut_BIT_MASK               (* (reg8 *) VSpeedOut__BIT_MASK)
/* Bypass Enable */
#define VSpeedOut_BYP                    (* (reg8 *) VSpeedOut__BYP)
/* Port wide control signals */                                                   
#define VSpeedOut_CTL                    (* (reg8 *) VSpeedOut__CTL)
/* Drive Modes */
#define VSpeedOut_DM0                    (* (reg8 *) VSpeedOut__DM0) 
#define VSpeedOut_DM1                    (* (reg8 *) VSpeedOut__DM1)
#define VSpeedOut_DM2                    (* (reg8 *) VSpeedOut__DM2) 
/* Input Buffer Disable Override */
#define VSpeedOut_INP_DIS                (* (reg8 *) VSpeedOut__INP_DIS)
/* LCD Common or Segment Drive */
#define VSpeedOut_LCD_COM_SEG            (* (reg8 *) VSpeedOut__LCD_COM_SEG)
/* Enable Segment LCD */
#define VSpeedOut_LCD_EN                 (* (reg8 *) VSpeedOut__LCD_EN)
/* Slew Rate Control */
#define VSpeedOut_SLW                    (* (reg8 *) VSpeedOut__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define VSpeedOut_PRTDSI__CAPS_SEL       (* (reg8 *) VSpeedOut__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define VSpeedOut_PRTDSI__DBL_SYNC_IN    (* (reg8 *) VSpeedOut__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define VSpeedOut_PRTDSI__OE_SEL0        (* (reg8 *) VSpeedOut__PRTDSI__OE_SEL0) 
#define VSpeedOut_PRTDSI__OE_SEL1        (* (reg8 *) VSpeedOut__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define VSpeedOut_PRTDSI__OUT_SEL0       (* (reg8 *) VSpeedOut__PRTDSI__OUT_SEL0) 
#define VSpeedOut_PRTDSI__OUT_SEL1       (* (reg8 *) VSpeedOut__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define VSpeedOut_PRTDSI__SYNC_OUT       (* (reg8 *) VSpeedOut__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(VSpeedOut__SIO_CFG)
    #define VSpeedOut_SIO_HYST_EN        (* (reg8 *) VSpeedOut__SIO_HYST_EN)
    #define VSpeedOut_SIO_REG_HIFREQ     (* (reg8 *) VSpeedOut__SIO_REG_HIFREQ)
    #define VSpeedOut_SIO_CFG            (* (reg8 *) VSpeedOut__SIO_CFG)
    #define VSpeedOut_SIO_DIFF           (* (reg8 *) VSpeedOut__SIO_DIFF)
#endif /* (VSpeedOut__SIO_CFG) */

/* Interrupt Registers */
#if defined(VSpeedOut__INTSTAT)
    #define VSpeedOut_INTSTAT            (* (reg8 *) VSpeedOut__INTSTAT)
    #define VSpeedOut_SNAP               (* (reg8 *) VSpeedOut__SNAP)
    
	#define VSpeedOut_0_INTTYPE_REG 		(* (reg8 *) VSpeedOut__0__INTTYPE)
#endif /* (VSpeedOut__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_VSpeedOut_H */


/* [] END OF FILE */
