/*******************************************************************************
* File Name: VSpeedIn.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_VSpeedIn_H) /* Pins VSpeedIn_H */
#define CY_PINS_VSpeedIn_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "VSpeedIn_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 VSpeedIn__PORT == 15 && ((VSpeedIn__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    VSpeedIn_Write(uint8 value);
void    VSpeedIn_SetDriveMode(uint8 mode);
uint8   VSpeedIn_ReadDataReg(void);
uint8   VSpeedIn_Read(void);
void    VSpeedIn_SetInterruptMode(uint16 position, uint16 mode);
uint8   VSpeedIn_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the VSpeedIn_SetDriveMode() function.
     *  @{
     */
        #define VSpeedIn_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define VSpeedIn_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define VSpeedIn_DM_RES_UP          PIN_DM_RES_UP
        #define VSpeedIn_DM_RES_DWN         PIN_DM_RES_DWN
        #define VSpeedIn_DM_OD_LO           PIN_DM_OD_LO
        #define VSpeedIn_DM_OD_HI           PIN_DM_OD_HI
        #define VSpeedIn_DM_STRONG          PIN_DM_STRONG
        #define VSpeedIn_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define VSpeedIn_MASK               VSpeedIn__MASK
#define VSpeedIn_SHIFT              VSpeedIn__SHIFT
#define VSpeedIn_WIDTH              1u

/* Interrupt constants */
#if defined(VSpeedIn__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in VSpeedIn_SetInterruptMode() function.
     *  @{
     */
        #define VSpeedIn_INTR_NONE      (uint16)(0x0000u)
        #define VSpeedIn_INTR_RISING    (uint16)(0x0001u)
        #define VSpeedIn_INTR_FALLING   (uint16)(0x0002u)
        #define VSpeedIn_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define VSpeedIn_INTR_MASK      (0x01u) 
#endif /* (VSpeedIn__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define VSpeedIn_PS                     (* (reg8 *) VSpeedIn__PS)
/* Data Register */
#define VSpeedIn_DR                     (* (reg8 *) VSpeedIn__DR)
/* Port Number */
#define VSpeedIn_PRT_NUM                (* (reg8 *) VSpeedIn__PRT) 
/* Connect to Analog Globals */                                                  
#define VSpeedIn_AG                     (* (reg8 *) VSpeedIn__AG)                       
/* Analog MUX bux enable */
#define VSpeedIn_AMUX                   (* (reg8 *) VSpeedIn__AMUX) 
/* Bidirectional Enable */                                                        
#define VSpeedIn_BIE                    (* (reg8 *) VSpeedIn__BIE)
/* Bit-mask for Aliased Register Access */
#define VSpeedIn_BIT_MASK               (* (reg8 *) VSpeedIn__BIT_MASK)
/* Bypass Enable */
#define VSpeedIn_BYP                    (* (reg8 *) VSpeedIn__BYP)
/* Port wide control signals */                                                   
#define VSpeedIn_CTL                    (* (reg8 *) VSpeedIn__CTL)
/* Drive Modes */
#define VSpeedIn_DM0                    (* (reg8 *) VSpeedIn__DM0) 
#define VSpeedIn_DM1                    (* (reg8 *) VSpeedIn__DM1)
#define VSpeedIn_DM2                    (* (reg8 *) VSpeedIn__DM2) 
/* Input Buffer Disable Override */
#define VSpeedIn_INP_DIS                (* (reg8 *) VSpeedIn__INP_DIS)
/* LCD Common or Segment Drive */
#define VSpeedIn_LCD_COM_SEG            (* (reg8 *) VSpeedIn__LCD_COM_SEG)
/* Enable Segment LCD */
#define VSpeedIn_LCD_EN                 (* (reg8 *) VSpeedIn__LCD_EN)
/* Slew Rate Control */
#define VSpeedIn_SLW                    (* (reg8 *) VSpeedIn__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define VSpeedIn_PRTDSI__CAPS_SEL       (* (reg8 *) VSpeedIn__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define VSpeedIn_PRTDSI__DBL_SYNC_IN    (* (reg8 *) VSpeedIn__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define VSpeedIn_PRTDSI__OE_SEL0        (* (reg8 *) VSpeedIn__PRTDSI__OE_SEL0) 
#define VSpeedIn_PRTDSI__OE_SEL1        (* (reg8 *) VSpeedIn__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define VSpeedIn_PRTDSI__OUT_SEL0       (* (reg8 *) VSpeedIn__PRTDSI__OUT_SEL0) 
#define VSpeedIn_PRTDSI__OUT_SEL1       (* (reg8 *) VSpeedIn__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define VSpeedIn_PRTDSI__SYNC_OUT       (* (reg8 *) VSpeedIn__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(VSpeedIn__SIO_CFG)
    #define VSpeedIn_SIO_HYST_EN        (* (reg8 *) VSpeedIn__SIO_HYST_EN)
    #define VSpeedIn_SIO_REG_HIFREQ     (* (reg8 *) VSpeedIn__SIO_REG_HIFREQ)
    #define VSpeedIn_SIO_CFG            (* (reg8 *) VSpeedIn__SIO_CFG)
    #define VSpeedIn_SIO_DIFF           (* (reg8 *) VSpeedIn__SIO_DIFF)
#endif /* (VSpeedIn__SIO_CFG) */

/* Interrupt Registers */
#if defined(VSpeedIn__INTSTAT)
    #define VSpeedIn_INTSTAT            (* (reg8 *) VSpeedIn__INTSTAT)
    #define VSpeedIn_SNAP               (* (reg8 *) VSpeedIn__SNAP)
    
	#define VSpeedIn_0_INTTYPE_REG 		(* (reg8 *) VSpeedIn__0__INTTYPE)
#endif /* (VSpeedIn__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_VSpeedIn_H */


/* [] END OF FILE */
